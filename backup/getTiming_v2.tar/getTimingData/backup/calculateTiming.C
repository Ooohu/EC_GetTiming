#include <iostream>

#include "getTimingClass.h"

using namespace std;

int main(){
	getTimingClass myClass;
}